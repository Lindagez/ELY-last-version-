import React from 'react'
import SideLogin from '../SideLogin/SideLogin'
import Footer from '../Footer/Footer'


const homeStyles = {
      p: {
        color: 'black',
        fontSize: '36px',
        fontWeight: 'bold',
        
      },
      h1: {
        color: 'blue',
        fontSize: '16px',
        fontWeight: 'bold',
      },
    }

function Home() {

  return (
    <>
    
    <p style={homeStyles.p}>Home Page </p><br />
    <p style={{color:'black'}}>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
    </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
      <p style={{ color: 'black' }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam consequuntur id consequatur, adipisci itaque dolorem commodi quis deserunt distinctio eos voluptates quia. Hic dicta corporis, temporibus et natus reprehenderit atque cupiditate, perspiciatis laboriosam harum suscipit. Consectetur minima adipisci natus dolore in, pariatur repellendus praesentium, ad perferendis sequi veritatis reprehenderit dolor eaque nemo illo eius, ut atque illum! Recusandae ipsam veritatis quasi quos, eos, quibusdam repellendus repudiandae possimus omnis aperiam exercitationem distinctio officiis impedit ipsum culpa incidunt vero? Laborum fuga velit magni eum laudantium saepe mollitia reiciendis inventore labore unde. Iusto ad eius voluptate rerum, laboriosam iste totam incidunt quasi delectus?
      </p>
    {<SideLogin />}
    <Footer />
    </>
  )
}

export default Home